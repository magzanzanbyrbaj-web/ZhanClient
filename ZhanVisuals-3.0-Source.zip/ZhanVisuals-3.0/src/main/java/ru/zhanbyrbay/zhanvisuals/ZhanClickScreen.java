package ru.zhanbyrbay.zhanvisuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class ZhanClickScreen extends Screen {
    private static final List<Entry> ENTRIES = List.of(
        new Entry("HUD", "hud", "Core"),
        new Entry("FPS Counter", "fps", "HUD"),
        new Entry("Coordinates", "coords", "HUD"),
        new Entry("Health HUD", "health", "Combat Visuals"),
        new Entry("Totem Counter", "totems", "Combat Visuals"),
        new Entry("Low Fire", "lowfire", "Render"),
        new Entry("Particle Effects", "particles", "Render"),
        new Entry("Armor HUD", "armor", "PvE / Farming"),
        new Entry("Farming Info", "farm", "PvE / Farming")
    );

    private int panelX, panelY, panelW, panelH;

    public ZhanClickScreen() {
        super(Component.literal("ZhanVisuals"));
    }

    @Override
    protected void init() {
        panelW = Math.min(430, this.width - 24);
        panelH = Math.min(300, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0x99000000);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF00C0C11);
        g.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFFFF343F);
        g.drawString(font, "ZHANVISUALS", panelX + 16, panelY + 14, 0xFFFF424D, false);
        g.drawString(font, "3.0.0  |  CLIENT SETTINGS", panelX + 16, panelY + 29, 0xFFAAAAAA, false);

        int y = panelY + 52;
        int colW = (panelW - 40) / 2;
        for (int i = 0; i < ENTRIES.size(); i++) {
            Entry e = ENTRIES.get(i);
            int col = i % 2;
            int row = i / 2;
            int x = panelX + 16 + col * (colW + 8);
            int rowY = y + row * 43;
            boolean on = ZhanConfig.enabled(e.id);
            int bg = on ? 0xFF251317 : 0xFF17171D;
            g.fill(x, rowY, x + colW, rowY + 34, bg);
            g.fill(x, rowY, x + 2, rowY + 34, on ? 0xFFFF424D : 0xFF44444A);
            g.drawString(font, e.name, x + 9, rowY + 6, 0xFFF1F1F1, false);
            g.drawString(font, on ? "ON" : "OFF", x + 9, rowY + 19, on ? 0xFFFF626B : 0xFF888888, false);
            g.drawString(font, e.category, x + colW - font.width(e.category) - 7, rowY + 19, 0xFF777780, false);
        }
        g.drawString(font, "Tap a module to toggle  |  ESC to close", panelX + 16,
            panelY + panelH - 16, 0xFF9999A2, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int y = panelY + 52;
        int colW = (panelW - 40) / 2;
        for (int i = 0; i < ENTRIES.size(); i++) {
            Entry e = ENTRIES.get(i);
            int col = i % 2;
            int row = i / 2;
            int x = panelX + 16 + col * (colW + 8);
            int rowY = y + row * 43;
            if (mouseX >= x && mouseX <= x + colW && mouseY >= rowY && mouseY <= rowY + 34) {
                ZhanConfig.toggle(e.id);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private record Entry(String name, String id, String category) {}
}
