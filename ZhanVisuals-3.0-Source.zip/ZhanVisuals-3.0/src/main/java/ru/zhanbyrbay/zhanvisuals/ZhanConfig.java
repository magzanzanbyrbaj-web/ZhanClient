package ru.zhanbyrbay.zhanvisuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class ZhanConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zhanvisuals.json");

    public static boolean hudEnabled = true;
    public static boolean fps = true;
    public static boolean coordinates = true;
    public static boolean health = true;
    public static boolean totems = true;
    public static boolean lowFire = true;
    public static boolean particles = true;
    public static boolean armorHud = true;
    public static boolean farmingInfo = true;

    private ZhanConfig() {}

    public static void toggle(String id) {
        switch (id) {
            case "hud" -> hudEnabled = !hudEnabled;
            case "fps" -> fps = !fps;
            case "coords" -> coordinates = !coordinates;
            case "health" -> health = !health;
            case "totems" -> totems = !totems;
            case "lowfire" -> lowFire = !lowFire;
            case "particles" -> particles = !particles;
            case "armor" -> armorHud = !armorHud;
            case "farm" -> farmingInfo = !farmingInfo;
        }
        save();
    }

    public static boolean enabled(String id) {
        return switch (id) {
            case "hud" -> hudEnabled;
            case "fps" -> fps;
            case "coords" -> coordinates;
            case "health" -> health;
            case "totems" -> totems;
            case "lowfire" -> lowFire;
            case "particles" -> particles;
            case "armor" -> armorHud;
            case "farm" -> farmingInfo;
            default -> false;
        };
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Data d = GSON.fromJson(Files.readString(FILE), Data.class);
                if (d != null) {
                    hudEnabled = d.hud; fps = d.fps; coordinates = d.coords;
                    health = d.health; totems = d.totems; lowFire = d.lowFire;
                    particles = d.particles; armorHud = d.armor; farmingInfo = d.farm;
                }
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(new Data(hudEnabled, fps, coordinates, health,
                totems, lowFire, particles, armorHud, farmingInfo)));
        } catch (Exception ignored) {}
    }

    private record Data(boolean hud, boolean fps, boolean coords, boolean health, boolean totems,
                        boolean lowFire, boolean particles, boolean armor, boolean farm) {}
}
