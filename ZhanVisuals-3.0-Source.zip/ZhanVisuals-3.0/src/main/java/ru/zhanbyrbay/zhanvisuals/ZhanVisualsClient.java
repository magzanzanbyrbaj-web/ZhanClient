package ru.zhanbyrbay.zhanvisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public final class ZhanVisualsClient implements ClientModInitializer {
    public static final String MOD_ID = "zhanvisuals";
    private boolean rightShiftWasDown = false;

    @Override
    public void onInitializeClient() {
        ZhanConfig.load();
        HudElementRegistry.attachElementBefore(
            VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath(MOD_ID, "main_hud"),
            this::renderHud
        );
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;
            boolean down = GLFW.glfwGetKey(client.getWindow().getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !rightShiftWasDown && client.screen == null) {
                client.setScreen(new ZhanClickScreen());
            }
            rightShiftWasDown = down;
        });
    }

    private void renderHud(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (!ZhanConfig.hudEnabled || mc.player == null || mc.options.hideGui) return;

        int x = 7, y = 7;
        int accent = 0xFFFF4242;
        int white = 0xFFF2F2F2;
        g.fill(x - 4, y - 4, x + 142, y + 65, 0x990B0B0F);
        g.fill(x - 4, y - 4, x + 142, y - 2, accent);
        g.drawString(mc.font, "ZHANVISUALS", x, y, accent, true);
        y += 12;

        if (ZhanConfig.fps) {
            g.drawString(mc.font, "FPS: " + mc.getFps(), x, y, white, true);
            y += 10;
        }
        if (ZhanConfig.coordinates) {
            var p = mc.player;
            g.drawString(mc.font, String.format("XYZ: %.1f %.1f %.1f", p.getX(), p.getY(), p.getZ()), x, y, white, true);
            y += 10;
        }
        if (ZhanConfig.health) {
            g.drawString(mc.font, String.format("HP: %.1f / %.1f", mc.player.getHealth(), mc.player.getMaxHealth()), x, y, white, true);
            y += 10;
        }
        if (ZhanConfig.totems) {
            int count = 0;
            for (ItemStack stack : mc.player.getInventory().items) {
                if (stack.is(Items.TOTEM_OF_UNDYING)) count += stack.getCount();
            }
            for (ItemStack stack : mc.player.getInventory().offhand) {
                if (stack.is(Items.TOTEM_OF_UNDYING)) count += stack.getCount();
            }
            g.drawString(mc.font, "TOTEMS: " + count, x, y, white, true);
        }
    }
}
